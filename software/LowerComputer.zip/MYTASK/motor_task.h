#ifndef __MOTOR_TASK_H
#define __MOTOR_TASK_H

#include "stm32f10x.h"

void motor_control(void);
void motor_test(void);

#endif

