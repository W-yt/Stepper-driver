#ifndef __SENSOR_TASK_H
#define __SENSOR_TASK_H

#include "stm32f10x.h"

void senser_read(void);


#endif

