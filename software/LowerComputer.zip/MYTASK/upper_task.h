#ifndef __UPPER_TASK_H
#define __UPPER_TASK_H

#include "stm32f10x.h"

//PC cmd define
#define 	START_CMD		0x01
#define 	STOP_CMD		0x02

void upper_send(void);
void upper_data_resolve(uint8_t cmd);

#endif

