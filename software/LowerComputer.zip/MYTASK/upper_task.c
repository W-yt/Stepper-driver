#include "upper_task.h"
#include "motor_task.h"

uint8_t upper_send_buffer[8] = {0};
uint8_t upper_rece_buffer[6] = {0};

extern uint32_t syscnt;
extern float senser_height;
extern uint8_t xmotor_start_flag;
extern uint8_t ymotor_start_flag;

void upper_data_resolve(uint8_t data)
{
	static uint8_t state = 0;
	
	//header
	if(state == 0 && data == 0xAA)
	{
		state = 1;
		upper_rece_buffer[0] = data;
	}
	//direction-x
	else if(state == 1)
	{
		state = 2;
		upper_rece_buffer[1] = data;
	}
	//direction-y
	else if(state == 2)
	{
		state = 3;
		upper_rece_buffer[2] = data;
	}
	//distance-x
	else if(state == 3)
	{
		state = 4;		
		upper_rece_buffer[3] = data;
	}
	//distance-y
	else if(state == 4)
	{
		state = 5;
		upper_rece_buffer[4] = data;
	}
	//ending
	else if(state == 5 && data == 0xBB)
	{
		state = 0;
		upper_rece_buffer[5] = data;
		
		//receive finish - refresh the flag
		xmotor_start_flag = 0;
		ymotor_start_flag = 0;
		
		motor_control();
	}
	else
		state = 0;
}

void upper_send(void)
{
	uint16_t senser_height_100 = 0;
	
	//header
	upper_send_buffer[0] = 0xAA;
	
	//time(low byte in front)
	upper_send_buffer[1] = (uint8_t)syscnt;
	upper_send_buffer[2] = (uint8_t)(syscnt>>8);
	upper_send_buffer[3] = (uint8_t)(syscnt>>16);
	upper_send_buffer[4] = (uint8_t)(syscnt>>24);
	
	//content(low byte in front)
	senser_height_100 = (uint16_t)(senser_height * 100);
	upper_send_buffer[5] = (uint8_t)senser_height_100;
	upper_send_buffer[6] = (uint8_t)senser_height_100>>8;
	
	//ending
	upper_send_buffer[7] = 0xBB;
	
	for(uint8_t i=0;i<=7;i++)
	{
		USART_SendData(USART1,upper_send_buffer[i]);
		
		while( USART_GetFlagStatus(USART1,USART_FLAG_TC)!= SET);
	}
}


