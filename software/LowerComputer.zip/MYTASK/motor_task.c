#include "motor_task.h"
#include "drv8825.h"
#include "tim.h"

#define xmotor_distance2time	20
#define ymotor_distance2time	20

int xmotor_start_time = 0;
int ymotor_start_time = 0;
int xmotor_stop_time = 0;
int ymotor_stop_time = 0;
uint8_t xmotor_start_flag = 0;
uint8_t ymotor_start_flag = 0;

extern uint8_t upper_rece_buffer[6];
extern uint8_t xmotor_enable_flag;
extern uint8_t ymotor_enable_flag;
extern uint8_t xmotor_dir_flag;
extern uint8_t ymotor_dir_flag;

void motor_control(void)
{
	uint8_t xmotor_move_distance = 0;
	uint8_t xmotor_move_time = 0;
	uint8_t ymotor_move_distance = 0;
	uint8_t ymotor_move_time = 0;
	
	//x motor forward
	if(upper_rece_buffer[1] == 0xFF)
	{
		xmotor_forward();
	}
	//x motor backward
	else if(upper_rece_buffer[1] == 0x00)
	{
		xmotor_backward();
	}
	
	//y motor forward
	if(upper_rece_buffer[2] == 0xFF)
	{
		ymotor_forward();
	}
	else if(upper_rece_buffer[2] == 0x00)
	{
		ymotor_backword();
	}
	
	//x motor move
	if(upper_rece_buffer[3] == 0)
	{
		xmotor_disable();
	}
	else
	{
		if(xmotor_start_flag == 0)
		{
			xmotor_start_time = getsystime();
			
			xmotor_move_distance = upper_rece_buffer[3];
			xmotor_move_time = xmotor_move_distance * xmotor_distance2time;
			
			xmotor_stop_time = xmotor_start_time + xmotor_move_time;

			xmotor_enable();
			xmotor_start_flag = 1;
		}
		else
		{
			if(getsystime() >= xmotor_stop_time)
			{
				xmotor_disable();
			}
		}
	}
	
	//y motor move
	if(upper_rece_buffer[4] == 0)
	{
		ymotor_disable();
	}
	else
	{
		if(ymotor_start_flag == 0)
		{
			ymotor_start_time = getsystime();
			
			ymotor_move_distance = upper_rece_buffer[4];
			ymotor_move_time = ymotor_move_distance * ymotor_distance2time;
			
			ymotor_stop_time = ymotor_start_time + ymotor_move_time;

			ymotor_enable();
			ymotor_start_flag = 1;
		}
		else
		{
			if(getsystime() >= ymotor_stop_time)
			{
				ymotor_disable();
			}
		}
	}
}

void motor_test(void)
{
	//enable
	if(xmotor_enable_flag == 1)
	{
		xmotor_enable();
	}
	else
	{
		xmotor_disable();
	}

	if(ymotor_enable_flag == 1)
	{
		ymotor_enable();
	}
	else
	{
		ymotor_disable();
	}
	
	//direction
	if(xmotor_dir_flag == XMOTOR_FORWARD)
	{
		xmotor_forward();
	}
	else if(xmotor_dir_flag == XMOTOR_BACKWARD)
	{
		xmotor_backward();
	}

	if(ymotor_dir_flag == YMOTOR_FORWARD)
	{
		ymotor_forward();
	}
	else if(ymotor_dir_flag == YMOTOR_BACKWARD)
	{
		ymotor_backword();
	}
}





