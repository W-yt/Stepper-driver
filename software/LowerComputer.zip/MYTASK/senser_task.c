#include "senser_task.h"
#include "adc.h"

float adc_voltage = 0.0f;
float senser_height = 0.0f;

extern uint16_t adc_origin_buffer[avg_times];

void senser_read(void)
{
	uint16_t adc_i = 0;
	
	float adc_value_sum = 0.0f;
	float adc_value = 0.0f; 

	for(adc_i=0;adc_i<avg_times;adc_i++)
	{
		adc_value_sum += adc_origin_buffer[adc_i];
	}
	
	adc_value = adc_value_sum / avg_times;
	
	adc_voltage = adc_value/4096.0f*3.3f;
	
	//here should be a formula
	senser_height = adc_voltage;
}




