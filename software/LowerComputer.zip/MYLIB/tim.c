#include "tim.h"
#include "stm32f10x.h"
#include "motor_task.h"
#include "senser_task.h"
#include "upper_task.h"
#include "drv8825.h"

uint32_t syscnt = 0;

extern uint8_t xmotor_enable_flag;
extern uint8_t ymotor_enable_flag;

void Tim_Init(void)
{
	TIM_TimeBaseInitTypeDef	TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
	
	TIM_TimeBaseStructure.TIM_Period = (1000-1);
	TIM_TimeBaseStructure.TIM_Prescaler = (720-1);
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
	TIM_TimeBaseInit(TIM1,&TIM_TimeBaseStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_ITConfig(TIM1,TIM_IT_Update,ENABLE);
	TIM_ARRPreloadConfig(TIM1,ENABLE);
	
	TIM_ClearFlag(TIM1,TIM_FLAG_Update);
	TIM_ClearITPendingBit(TIM1,TIM_IT_Update);
	
	TIM_Cmd(TIM1,ENABLE);
}

void TIM1_UP_IRQHandler()
{
	if(TIM_GetITStatus(TIM1,TIM_IT_Update))
	{
		//1 syscnt means 10ms
		syscnt++;
		
		//50ms
		if(syscnt%5 == 0)
		{			
			senser_read();
			
			upper_send();
			
			//motor control test
			motor_test();
		}
				
		TIM_ClearITPendingBit(TIM1,TIM_IT_Update);
	}
}

uint32_t getsystime(void)
{
	return syscnt;
}















