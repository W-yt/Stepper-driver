#ifndef __USART_H
#define __USART_H	 

#include "stm32f10x.h"

void Usart_Init(void);

#endif





