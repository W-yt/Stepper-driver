#ifndef __ADC_H
#define __ADC_H

#include "stm32f10x.h"

#define avg_times 20

void Adc_Init(void);

#endif


