#ifndef __TIM_H
#define __TIM_H

#include "stm32f10x.h"

void Tim_Init(void);
uint32_t getsystime(void);

#endif



