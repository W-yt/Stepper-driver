#include "drv8825.h"
#include "stm32f10x.h"

//operate founctions
#define mode0_high()		GPIO_SetBits(GPIOB,GPIO_Pin_6)
#define mode0_low()			GPIO_ResetBits(GPIOB,GPIO_Pin_6)
#define mode1_high()		GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define mode1_low()			GPIO_ResetBits(GPIOB,GPIO_Pin_7)
#define mode2_high()		GPIO_SetBits(GPIOB,GPIO_Pin_8)
#define mode2_low()			GPIO_ResetBits(GPIOB,GPIO_Pin_8)

uint8_t xmotor_enable_flag = 0;
uint8_t ymotor_enable_flag = 0;
uint8_t xmotor_dir_flag = XMOTOR_FORWARD;
uint8_t ymotor_dir_flag = YMOTOR_FORWARD;

void Enable_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	//xmotor
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
		
	//ymotor
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);

	//disable the two motor when power on
	GPIO_SetBits(GPIOB,GPIO_Pin_9);
	GPIO_SetBits(GPIOB,GPIO_Pin_5);
}

void Mode_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);

	//full step mode when power on
	GPIO_ResetBits(GPIOB,GPIO_Pin_6);
	GPIO_ResetBits(GPIOB,GPIO_Pin_7);
	GPIO_ResetBits(GPIOB,GPIO_Pin_8);
}

void set_motormode(uint8_t split_num)
{
	//full step mode
	if(split_num == 0)
	{
		mode0_low();
		mode1_low();
		mode2_low();
	}
	//half step mode 
	else if(split_num == 2)
	{
		mode0_high();
		mode1_low();
		mode2_low();
	}
	//(1/4) step mode 
	else if(split_num == 4)
	{
		mode0_low();
		mode1_high();
		mode2_low();
	}
	//(1/8) step mode 
	else if(split_num == 8)
	{
		mode0_high();
		mode1_high();
		mode2_low();
	}
	//(1/16) step mode 
	else if(split_num == 16)
	{
		mode0_low();
		mode1_low();
		mode2_high();
	}
	//(1/32) step mode 
	else if(split_num == 32)
	{
		mode0_high();
		mode1_high();
		mode2_high();
	}
	//error input means full step mode
	else
	{
		mode0_low();
		mode1_low();
		mode2_low();
	}
}

void Direction_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;
	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	//select forward direction when power on
	xmotor_forward();
	ymotor_forward();
}

void Step_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef TIM_OCInitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
																																							 
	//TIM3 CH1
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	//TIM3 CH2
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	//1KHz
	TIM_TimeBaseStructure.TIM_Period = (1000-1);       
	TIM_TimeBaseStructure.TIM_Prescaler = (72-1);
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
	
	//TIM3 CH1 -- 1KHz 50%
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = (500-1);
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC1Init(TIM3, &TIM_OCInitStructure);

	//TIM3 CH2 -- 1KHz 50%
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM2;
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStructure.TIM_Pulse = (500-1);
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OC2Init(TIM3, &TIM_OCInitStructure);

	//start output when power on 
	TIM_CtrlPWMOutputs(TIM3,ENABLE);
	TIM_ARRPreloadConfig(TIM3,ENABLE);
	TIM_Cmd(TIM3,ENABLE);
}

void xmotor_enable(void)
{
	GPIO_ResetBits(GPIOB,GPIO_Pin_9); 
	xmotor_enable_flag = 1;
}	

void xmotor_disable(void)	
{
	GPIO_SetBits(GPIOB,GPIO_Pin_9); 
	xmotor_enable_flag = 0;
}

void ymotor_enable(void)		
{
	GPIO_ResetBits(GPIOB,GPIO_Pin_5); 
	ymotor_enable_flag = MOTOR_ENABLE;
}	


void ymotor_disable(void)	
{
	GPIO_SetBits(GPIOB,GPIO_Pin_5); 
	ymotor_enable_flag = MOTOR_DISABLE;
}	

void xmotor_forward(void)	
{
	GPIO_SetBits(GPIOA,GPIO_Pin_4);
	xmotor_dir_flag = XMOTOR_FORWARD;
}	

void xmotor_backward(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	xmotor_dir_flag = XMOTOR_BACKWARD;	
}	

void ymotor_forward(void)	
{
	GPIO_SetBits(GPIOA,GPIO_Pin_5);
	ymotor_dir_flag = YMOTOR_FORWARD;	
}	

void ymotor_backword(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_5);
	ymotor_dir_flag = YMOTOR_BACKWARD;	
}	




