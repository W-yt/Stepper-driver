#ifndef __DRV8825_H
#define __DRV8825_H

#include "stm32f10x.h"

#define MOTOR_ENABLE  1
#define MOTOR_DISABLE 0
#define XMOTOR_FORWARD 	101
#define XMOTOR_BACKWARD 102
#define YMOTOR_FORWARD 	103
#define YMOTOR_BACKWARD 104

void Enable_Init(void);
void Mode_Init(void);
void set_motormode(uint8_t split_num);
void Direction_Init(void);
void Step_Init(void);
void xmotor_enable(void);
void xmotor_disable(void);
void ymotor_enable(void);
void ymotor_disable(void);
void xmotor_forward(void);
void xmotor_backward(void);
void ymotor_forward(void);
void ymotor_backword(void);

#endif

