#include "stm32f10x.h"
#include "delay.h"
#include "led.h"
#include "drv8825.h"
#include "usart.h"
#include "tim.h"
#include "adc.h"

#define motor_subdivide 32

int main( void )
{
	Led_Init();
	Usart_Init();
	Enable_Init();
	Mode_Init();
	Direction_Init();
	Step_Init();
	Tim_Init();
	Adc_Init();
	
	//32 step mode
	set_motormode(motor_subdivide);
		
	while( 1 )
	{
		;
	}
}




